﻿namespace CommandPattern.Core.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
