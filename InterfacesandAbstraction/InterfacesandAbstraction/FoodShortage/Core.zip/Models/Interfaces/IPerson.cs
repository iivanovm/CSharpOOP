﻿namespace BorderControl.Models.Interfaces
{
    public interface IPerson
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}
