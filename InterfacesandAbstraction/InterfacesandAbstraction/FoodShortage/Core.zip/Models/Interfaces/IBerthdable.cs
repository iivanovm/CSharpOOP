﻿namespace BirthdayCelebrations.Models.Interfaces
{
    public interface IBerthdable
    {
        public string Birthday { get; set; }
    }
}
