﻿namespace BorderControl.IO.interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
