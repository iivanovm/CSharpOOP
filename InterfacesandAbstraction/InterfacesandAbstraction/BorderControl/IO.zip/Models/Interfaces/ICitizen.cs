﻿namespace BorderControl.Models.Interfaces
{
    public interface ICitizen : IPerson
    {
        public int Age { get; set; }
    }
}
