﻿namespace BorderControl.Core.Interface
{
    public interface IEngine
    {
        void Run();
    }
}
