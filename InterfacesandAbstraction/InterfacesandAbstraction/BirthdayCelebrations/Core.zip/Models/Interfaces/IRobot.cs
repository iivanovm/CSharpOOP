﻿namespace BorderControl.Models.Interfaces;

public interface IRobot:IPerson
{

}
