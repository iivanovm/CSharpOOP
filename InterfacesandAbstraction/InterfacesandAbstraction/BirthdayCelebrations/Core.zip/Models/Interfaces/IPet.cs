﻿namespace BirthdayCelebrations.Models.Interfaces;

using BorderControl.Models.Interfaces;

public interface IPet :IPerson,IBerthdable
{
   
}
