﻿using BorderControl.IO.interfaces;

namespace BorderControl.IO
{
    public class ConsoleWriter : IWriter
    {
        public void Write(string texName)
        {
            throw new NotImplementedException();
        }

        public void WriteLine(string texName)
        {
            throw new NotImplementedException();
        }
    }
}
