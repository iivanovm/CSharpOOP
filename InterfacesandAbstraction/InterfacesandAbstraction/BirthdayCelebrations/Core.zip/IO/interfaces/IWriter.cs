﻿namespace BorderControl.IO.interfaces
{
    public interface IWriter
    {
        void Write(string texName);
        void WriteLine(string texName);
    }
}
