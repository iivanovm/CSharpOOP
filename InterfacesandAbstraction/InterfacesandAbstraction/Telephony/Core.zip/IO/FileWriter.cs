﻿namespace Telephony.IO
{
    using Interfaces;

    //TODO: Implement it in home!
    public class FileWriter : IWriter
    {
        public void Write(string text)
        {
            throw new System.NotImplementedException();
        }

        public void WriteLine(string text)
        {
            throw new System.NotImplementedException();
        }
    }
}
