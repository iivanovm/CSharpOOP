﻿namespace Shapes.Models.Contracts;

public interface IDrawable
{
    void Draw();
}
