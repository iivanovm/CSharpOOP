﻿namespace CollectionHierarchy.IO.interfaces;

public interface IReader
{
    string Read();
}
