﻿namespace Cars.Models.Interfaces
{
    internal interface IElectricCar
    {
        int Battery { get; set; }
    }
}
