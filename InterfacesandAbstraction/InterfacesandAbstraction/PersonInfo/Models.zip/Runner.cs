﻿namespace PersonInfo;

public  class Runner
{
    public static void Run()
    {
        Engine.Start();
    }
}
