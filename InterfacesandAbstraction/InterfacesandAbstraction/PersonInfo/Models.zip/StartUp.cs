﻿using PersonInfo;

public class StartUp
{
    public static void Main()
    {
        Runner.Run();
    }
}
