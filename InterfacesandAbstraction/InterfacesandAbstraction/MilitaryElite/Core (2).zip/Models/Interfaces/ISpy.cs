﻿namespace MilitaryElite.Models.Interfaces;

public interface ISpy:ISoldier
{
    int SpyNumber { get;  }
}
