﻿namespace MilitaryElite.Models.Interfaces;
using Enums;
public interface ICommando:ISpecialisedSoldier
{

    void CompleteMission();
}
