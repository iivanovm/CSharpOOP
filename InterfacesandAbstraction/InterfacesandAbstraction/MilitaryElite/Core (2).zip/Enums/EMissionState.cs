﻿namespace MilitaryElite.Enums;

public enum EMissionState
{
    inProgress=0, Finished=1
}
