﻿namespace MilitaryElite.Enums;


public enum ECorps
{
    Airforces = 0,
    Marines = 1,
    Def = 2
}
