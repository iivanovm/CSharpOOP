﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class SpaceForces : MilitaryUnit
    {
        private const double SpaceTrPrice = 11;
        public SpaceForces() : base(SpaceTrPrice)
        {
        }
    }


}
