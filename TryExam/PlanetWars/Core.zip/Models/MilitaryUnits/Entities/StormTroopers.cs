﻿namespace PlanetWars.Models.MilitaryUnits.Entities
{
    public class StormTroopers : MilitaryUnit
    {
        private const double StormTrPrice = 2.5;
        public StormTroopers() : base(StormTrPrice)
        {
        }
    }


}
