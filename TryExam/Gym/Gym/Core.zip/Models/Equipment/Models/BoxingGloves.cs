﻿namespace Gym.Models.Equipment.Models
{
    public class BoxingGloves : Equipment
    {
      

        public BoxingGloves() 
            : base(227, 120)
        {
        }
    }
}
