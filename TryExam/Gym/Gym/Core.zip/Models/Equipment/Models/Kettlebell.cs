﻿namespace Gym.Models.Equipment.Models
{
    public class Kettlebell : Equipment
    {
       

        public Kettlebell()
            : base(10000, 80)
        {
        }
    }
}

