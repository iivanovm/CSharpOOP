namespace Database.Tests;

using NUnit.Framework;
using System;
using System.Linq;

[TestFixture]
public class DatabaseTests
{
    private int[] data;
    private int[] dataTestC;
    private int count;
    private Database database;
    private Database databaseTestMethod;



    [SetUp]
    public void SeUp()
    {
        data = new int[16];
        database = new Database(data);
        dataTestC = new int[16];
        databaseTestMethod = new Database(dataTestC);
           
    }

    [Test]
    public void CheckCountElements()
    {
        Assert.AreEqual(data.Length, database.Count);
    }
    [Test]
    public void CheckCapacityGreatBySixtten()
    {
        int [] currentData= new int[55];
       
        Assert.Throws<InvalidOperationException>(() =>
        {
            database = new Database(currentData);
        });
    }

    [Test]
    public void CheckInitializationDatabaseWhenLenghtLessThanSixtten()
    {
        int[] current= new int[16];
        database = new Database(current);
        Assert.AreEqual (data.Length, database.Count);
    }
    [Test]
    public void CheckInitializationAddMethod()
    {
        int sum = 0;
        database = new Database(data);
        
        int sumarr = data.Sum();
        Assert.AreEqual(data.Sum(), sumarr);
    }

    [Test]
    public void CheckRemoveMethodI()
    {
        database.Remove();
        Assert.AreEqual(15, database.Count);
    }
    [Test]
    public void CheckRemoveMethodLastElement()
    {
        database = new Database(data);
        database.Remove();
        Assert.AreEqual(data.Length-1, database.Count);
    }

    [Test]
    public void CheckLastElementDatabaseAfterRemove()
    {
        database = new Database(data);
        database.Remove();
        int[] afterRemove = database.Fetch();
        Assert.AreEqual(afterRemove.Last(), 0);
    }

    [Test]
    public void CheckLastElementDatabaseBeforeRemove()
    {
        int[] currentData = new int[0];
        database = new Database(currentData);
        Assert.Throws<InvalidOperationException>(() => database.Remove());
    }
    [Test]
    public void CheckLastElementDatabaseFetchIsZero()
    {
        int[] currentData = new int[0];
        database = new Database(currentData);
        Assert.AreEqual(0,database.Fetch().Count());
    }
    [Test]
    public void CheckLastElementDatabaseFetchIsSexteen()
    {
        int[] currentData = new int[16];
        database = new Database(currentData);
        Assert.AreEqual(currentData.Length, database.Fetch().Count());
    }
    [Test]
    public void CheckElementsWhenUseFetch()
    {
        int[] currentData = new int[] {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15 };
        database = new Database(currentData);
        Assert.AreEqual(currentData, database.Fetch());
    }



}



