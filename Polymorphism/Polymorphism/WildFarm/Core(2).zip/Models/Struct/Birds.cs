﻿namespace WildFarm.Models.Struct;

public  record  struct Birds(string Name, double Weight, double WingSize);


