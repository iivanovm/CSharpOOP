﻿namespace WildFarm.Models.Struct;
//string name, double weight, int foodEaten, string livingRegion, string breed
public struct Felines
{
    public string Name { get; set; }
    public double Weight { get; set; }
    public int food { get; set; }
    public string LivingRegion { get; set; }
    public string Breed { get; set; }

    
}
