﻿namespace WildFarm.Enums
{
    public enum HensEat
    {
        Vegetable,
        Fruit,
        Meat,
        Seeds
    }
}
