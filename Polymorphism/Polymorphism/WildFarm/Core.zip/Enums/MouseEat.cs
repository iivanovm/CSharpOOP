﻿namespace WildFarm.Enums
{
    public enum MouseEat
    {
        Vegetable,
        Fruit,
    }
}
