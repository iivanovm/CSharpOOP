﻿namespace WildFarm.Enums
{
    public enum TigerEat
    {
        Meat
    }
}
