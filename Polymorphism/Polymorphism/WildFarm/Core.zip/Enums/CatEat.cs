﻿namespace WildFarm.Enums
{
    public enum CatEat
    {
        Vegetable,
        Meat
    }
}
