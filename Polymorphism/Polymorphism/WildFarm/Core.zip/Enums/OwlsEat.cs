﻿namespace WildFarm.Enums
{
    public enum OwlsEat
    {
        Meat
    }
}
