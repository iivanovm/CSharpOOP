﻿namespace WildFarm.Enums
{
    public enum DogEat
    {
        Meat
    }
}
