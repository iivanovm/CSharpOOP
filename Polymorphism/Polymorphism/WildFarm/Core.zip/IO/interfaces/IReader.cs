﻿namespace WildFarm.IO.interfaces;

public interface IReader
{
    string ReadLine();
}
