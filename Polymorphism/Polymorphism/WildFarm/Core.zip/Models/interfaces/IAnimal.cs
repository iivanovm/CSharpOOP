﻿namespace WildFarm.Models.interfaces;

public interface IAnimal
{
    string ProduceSound();
}
