﻿namespace WildFarm.Models.AbstractCl;

public abstract class Food
{
    protected int Quantity { get; private set; }
}