﻿namespace WildFarm.Models.Struct;

public record struct Dogs (string Name,double Weight,string Living);
