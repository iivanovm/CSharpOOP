﻿namespace Raiding.IO.interfaces;

public interface IReader
{
    string Read();
}
