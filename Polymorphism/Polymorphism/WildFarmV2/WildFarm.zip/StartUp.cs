﻿using WildFarm;
using WildFarm.Core;
using WildFarm.Core.interfaces;
using WildFarm.Factories.interfaces;
using WildFarm.IO;
using WildFarm.IO.interfaces;

public class StartUp
{
    public static void Main()
    {
        IReader reader = new ConsoleReader();
        IWriter writer = new ConsoleWriter();
        IFoodFactory food = new FoodFactory();
        IAnimalFactory animal= new AnimalFactory();
        IEngine engine = new Engine(reader,writer,animal,food);
        engine.Run();
    }
}