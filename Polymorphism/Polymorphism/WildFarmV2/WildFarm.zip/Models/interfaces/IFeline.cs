﻿namespace WildFarm.Models.interfaces;

public interface IFeline : IMammal
{
    string Breed { get; }
}