﻿namespace WildFarm.Models.interfaces;

public interface IFood
{
    int Quantity { get; }
}
