﻿namespace WildFarm.Models.interfaces;

public interface IMammal
{
    string LivinigRegion { get; }
}