﻿namespace WildFarm.Models.interfaces;

public interface IBird
{
    double WingSize { get; }
}