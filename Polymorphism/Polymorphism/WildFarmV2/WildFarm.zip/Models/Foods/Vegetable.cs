﻿namespace WildFarm.Models.Foods;
using Models;


public class Vegetable : Food
{
    public Vegetable(int quantity)
        : base(quantity)
    {

    }
}
