﻿namespace WildFarm.Models.Foods;
using Models;

public class Meat : Food
{
    public Meat(int quantity)
        : base(quantity)
    {

    }
}